import { useEffect, useRef } from "react";

/** Fades content in once when it scrolls into view. Skipped for reduced-motion users. */
export function Reveal({ as: Tag = "div", className = "", children, ...rest }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.classList.add("in");
      return;
    }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { el.classList.add("in"); io.disconnect(); }
    }, { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <Tag ref={ref} className={`reveal ${className}`} {...rest}>{children}</Tag>;
}

/** A photograph with a fixed aspect ratio and an optional caption. */
export function Photo({ img, ratio = "4/3", pos = "center", caption = true, className = "" }) {
  return (
    <figure className={`photo ${className}`}>
      <img src={img.src} alt={img.alt} loading="lazy" style={{ aspectRatio: ratio, objectPosition: pos }} />
      {caption && img.caption && <figcaption>{img.caption}</figcaption>}
    </figure>
  );
}

/** Page opening: title and intro on the left, photograph on the right. */
export function PageHead({ kicker, title, children, img, ratio, pos }) {
  return (
    <header className="pagehead">
      <div className="wrap split">
        <div className="split-text">
          <p className="kicker">{kicker}</p>
          <h1>{title}</h1>
          <div className="lead">{children}</div>
        </div>
        <Photo img={img} ratio={ratio || "4/3"} pos={pos} />
      </div>
    </header>
  );
}

/** Text beside a photograph. `flip` puts the photograph on the left. */
export function Split({ flip = false, img, ratio, pos, children, className = "" }) {
  return (
    <Reveal className={`split ${flip ? "flip" : ""} ${className}`}>
      <div className="split-text">{children}</div>
      <Photo img={img} ratio={ratio || "4/3"} pos={pos} />
    </Reveal>
  );
}

export const Band = ({ tone = "", children, className = "", ...rest }) => (
  <section className={`band ${tone} ${className}`} {...rest}><div className="wrap">{children}</div></section>
);
