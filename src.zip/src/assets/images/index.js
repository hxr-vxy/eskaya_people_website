// One place to register every photograph, with the caption and credit used wherever it appears.
// Credits are marked "to be confirmed" on purpose: replace each with the photographer / source you verify.
import hero from "./home/bohol-landscape-hero.jpg";
import villageRoad from "./home/bohol-upland-village-road.jpg";
import elder from "./community/eskaya-community-elder.jpg";
import reading from "./community/eskaya-community-reading.jpg";
import hillsOverview from "./community/bohol-chocolate-hills-overview.jpg";
import hillsSunrise from "./history/bohol-chocolate-hills-sunrise.jpg";
import tinikling from "./history/tinikling-bamboo-dance.jpg";
import folkDance from "./history/cultural-dance-performance.jpg";
import manuscript from "./digital/eskaya-script-manuscript.jpg";
import manuscriptDetail from "./digital/eskaya-script-manuscript-detail.jpg";

import lovelyn from "./creators/lovelyn-pojas.png";
import harvey from "./creators/harvey-quibol.png";
import jilliane from "./creators/jilliane-aguanza.png";
import amber from "./creators/amber.png";
import jelyn from "./creators/jelyn.jpg";
import kervee from "./creators/kervee.png";
import jarl from "./creators/jarl.png";
import francis from "./creators/francis.png";

export const CREDIT = "Source to be confirmed";

export const IMG = {
  hero:            { src: hero, alt: "Chocolate Hills of Bohol in warm light", caption: "The Chocolate Hills, one of Bohol's best-known landscapes." },
  villageRoad:     { src: villageRoad, alt: "A road through an upland village in Bohol", caption: "Upland landscape of southeastern Bohol." },
  elder:           { src: elder, alt: "A smiling community elder", caption: "A community elder." },
  reading:         { src: reading, alt: "A community member reading from a handwritten book", caption: "A community member reading from a handwritten book." },
  hillsOverview:   { src: hillsOverview, alt: "Chocolate Hills, Bohol", caption: "The Chocolate Hills, one of Bohol's best-known landscapes." },
  hillsSunrise:    { src: hillsSunrise, alt: "Chocolate Hills at sunrise", caption: "The hills of Bohol at sunrise." },
  tinikling:       { src: tinikling, alt: "Traditional Philippine dance performance", caption: "Tinikling, a Philippine folk dance. Not specific to the Eskaya." },
  folkDance:       { src: folkDance, alt: "Philippine folk dance in traditional dress", caption: "Philippine folk dance in traditional dress. Not specific to the Eskaya." },
  manuscript:      { src: manuscript, alt: "Handwritten page in the Eskaya script", caption: "A handwritten page in the Eskaya script." },
  manuscriptDetail:{ src: manuscriptDetail, alt: "Close-up of handwritten Eskaya script", caption: "Close-up of handwritten Eskaya script." },
};

export const TEAM = { lovelyn, harvey, jilliane, amber, jelyn, kervee, jarl, francis };
