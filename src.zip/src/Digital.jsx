import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import Footer from "./Footer.jsx";

import { IMG, CREDIT } from "./assets/images/index.js";
import { Reveal, Photo, Split, Band } from "./components.jsx";

// Titles describe what each photograph actually shows. Credits are placeholders until sources are confirmed.
const PHOTOS = [
  { img: IMG.hillsOverview, title: "Chocolate Hills", place: "Bohol, Philippines", desc: "The best-known landscape of Bohol's interior." },
  { img: IMG.elder, pos: "30% 30%", title: "Community Elder", place: "Southeastern Bohol", desc: "A community member in the uplands." },
  { img: IMG.reading, pos: "25% 40%", title: "Reading Together", place: "Southeastern Bohol", desc: "A community member reading from a handwritten book." },
  { img: IMG.villageRoad, title: "Upland View", place: "Bohol, Philippines", desc: "A village road in the island interior." },
  { img: IMG.manuscript, title: "Eskaya Script", place: "Bohol, Philippines", desc: "A handwritten page in the Eskaya script." },
  { img: IMG.manuscriptDetail, title: "Script Close-up", place: "Eskaya script", desc: "Detail of handwritten Eskaya characters." },
  { img: IMG.hillsSunrise, pos: "center 60%", title: "Hills at Sunrise", place: "Bohol, Philippines", desc: "Early light over the hills of Bohol." },
  { img: IMG.tinikling, pos: "center 30%", title: "Tinikling", place: "Philippines", desc: "A Philippine folk dance, not specific to the Eskaya." },
  { img: IMG.folkDance, pos: "center 20%", title: "Folk Dance", place: "Philippines", desc: "Traditional dress and dance, not specific to the Eskaya." },
];

// Approximate municipal centres only: no barangay or private-site detail.
const PLACES = [
  { name: "Pilar", pos: [9.81, 124.34], note: "A principal centre of Eskaya cultural life" },
  { name: "Guindulman", pos: [9.75, 124.48], note: "Home to several Eskaya barangays" },
  { name: "Duero", pos: [9.72, 124.4], note: "Southeastern coastal and inland areas" },
  { name: "Garcia Hernandez", pos: [9.61, 124.3], note: "Upland Eskaya communities" },
];

const TIMELINE = [
  { when: "Pre-16th Century", title: "Pre-Colonial Period", text: "The ancestors of the Eskaya inhabit the interior highlands of Bohol as part of the indigenous population of the Visayas. They develop distinct cultural practices, oral traditions, and a writing system." },
  { when: "1565", title: "Spanish Colonization Begins", text: "Spanish colonization of the Philippines begins under Miguel López de Legazpi, initially based in Cebu. The reducción policy attempts to resettle indigenous inland communities into coastal and lowland towns." },
  { when: "16th–19th Century", title: "Interior Retreat", text: "Many interior communities in Bohol, including ancestors of the Eskaya, maintain their way of life in the mountains, away from direct colonial administration and Christian mission settlements." },
  { when: "1898", title: "End of Spanish Colonial Rule", text: "Spain cedes the Philippines to the United States following the Spanish-American War. The Philippine-American War follows, with significant impact on indigenous communities across the archipelago." },
  { when: "20th Century", title: "Documentation of the Eskaya Script", text: "Researchers and government officials begin documenting the Eskaya community and its unique writing system. The community maintains its script and language through this period." },
  { when: "1987", title: "Philippine Constitution", text: "The 1987 Philippine Constitution recognizes the rights of indigenous cultural communities to preserve their culture, traditions, and institutions, providing a foundation for later indigenous rights legislation." },
  { when: "1997", title: "IPRA, Republic Act No. 8371", text: "The Indigenous Peoples' Rights Act is signed into law. It recognizes the rights of indigenous cultural communities to ancestral domain, self-governance, and cultural integrity and establishes the National Commission on Indigenous Peoples (NCIP)." },
  { when: "2011", title: "IPEd Framework", text: "The Department of Education issues Order No. 62, s. 2011, establishing the Indigenous Peoples' Education (IPEd) program to integrate indigenous knowledge and culture into formal schooling." },
  // NOTE: the brief said "2020 – Unicode 13.0: Eskaya Script Encoded". Unicode 13.0 (2020) added
  // Dives Akuru at U+11900–U+1195F, not Eskaya, so this entry is worded neutrally until verified.
  { when: "2020s", title: "Digital Documentation of the Script", text: "Fonts, digital archives, and encoding proposals are part of ongoing efforts to represent the Eskaya script digitally, supporting its documentation and preservation." },
  { when: "Present", title: "Living Community", text: "The Eskaya continue as a living community in southeastern Bohol, navigating contemporary challenges while working to preserve their language, script, and cultural heritage for future generations." },
];

const FACTS = [
  { k: "What it is", v: "A syllabary: each character stands for a syllable, not a single consonant or vowel." },
  { k: "Distinct from Baybayin", v: "Visually and structurally different from Baybayin and other known Philippine scripts." },
  { k: "Size", v: "About 71–75 characters documented in academic sources." },
  { k: "Direction", v: "Written left to right." },
];

const STEPS = [
  { h: "Identity", p: "Those who read, write, and speak Eskaya are considered fully Eskaya in the cultural sense." },
  { h: "Oral + written", p: "The script records oral texts so they can be passed on and consulted." },
  { h: "Documentation", p: "Linguists and anthropologists, including Jason William Lobel, have published research on the language and script." },
  { h: "Digital recognition", p: "Digital representation of the script is part of its wider preservation effort." },
];

function TerritoryMap() {
  const el = useRef(null);
  useEffect(() => {
    const map = L.map(el.current, { scrollWheelZoom: false }).setView([9.85, 124.15], 9);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 13,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);
    L.circle([9.72, 124.4], { radius: 14000, color: "#7b5330", weight: 2, fillColor: "#b9a15a", fillOpacity: 0.18 })
      .addTo(map).bindTooltip("General area of Eskaya communities", { sticky: true });
    PLACES.forEach((p) =>
      L.circleMarker(p.pos, { radius: 7, color: "#17291f", weight: 2, fillColor: "#e6d9a6", fillOpacity: 1 })
        .addTo(map).bindPopup(`<strong>${p.name}</strong><br/>${p.note}`)
        .bindTooltip(p.name, { permanent: true, direction: "right", offset: [8, 0], className: "map-label" }));
    L.marker([9.65, 123.85], { opacity: 0 }).addTo(map)
      .bindTooltip("BOHOL", { permanent: true, direction: "center", className: "map-label map-island" });
    return () => map.remove();
  }, []);
  return <div ref={el} className="territory-map" role="region" aria-label="Map of southeastern Bohol" />;
}

function Digital() {
  const [open, setOpen] = useState(0);
  return (
    <>
      <header className="pagehead">
        <div className="wrap split">
          <div className="split-text">
            <p className="kicker">Digital Heritage</p>
            <h1>Visual Record &amp; Interactive Features</h1>
            <div className="lead"><p>A photo gallery, map, infographic, and timeline presenting the Eskaya and their homeland.</p></div>
          </div>
          <Photo img={IMG.hillsSunrise} ratio="4/3" pos="center 62%" />
        </div>
      </header>

      <Band>
        <Reveal>
          <h2>Photo Gallery</h2>
          <p className="d-lead">Hover over, or tap, a photograph to see its title and place.</p>
        </Reveal>
        <div className="gallery">
          {PHOTOS.map((ph) => (
            <figure key={ph.title} className="g-item" tabIndex={0}>
              <img src={ph.img.src} alt={`${ph.title}, ${ph.place}`} loading="lazy" style={{ objectPosition: ph.pos || "center" }} />
              <figcaption>
                <strong>{ph.title}</strong>
                <span>{ph.place}</span>
                <em>{ph.desc}</em>
                <small>Credit: {CREDIT}</small>
              </figcaption>
            </figure>
          ))}
        </div>
      </Band>

      <Band tone="tint">
        <Reveal>
          <h2>Interactive Map: Eskaya Territory</h2>
          <p className="d-lead">Southeastern Bohol. Markers show municipal centres only; the shaded circle is a general area, not a boundary.</p>
        </Reveal>
        <TerritoryMap />
        <p className="map-note">Locations are approximate. Barangay-level and private sites are intentionally not shown.</p>
      </Band>

      <Band>
        <Split img={IMG.manuscriptDetail} ratio="3/2">
          <h2>The Eskaya Writing System</h2>
          <p className="d-lead">An indigenous script that carries language and identity.</p>
          <div className="card-grid two compact">
            {FACTS.map((f) => (<div key={f.k} className="card pad accent"><h3>{f.k}</h3><p>{f.v}</p></div>))}
          </div>
        </Split>
        <Reveal as="ol" className="flow">
          {STEPS.map((s, i) => (<li key={s.h}><span>{i + 1}</span><h4>{s.h}</h4><p>{s.p}</p></li>))}
        </Reveal>
      </Band>

      <Band tone="tint">
        <Reveal>
          <h2>Digital Timeline: Eskaya History</h2>
          <p className="d-lead">Select an entry to read more.</p>
        </Reveal>
        <ol className="timeline">
          {TIMELINE.map((t, i) => (
            <Reveal as="li" key={t.when} className={i === open ? "on" : ""}>
              <button onClick={() => setOpen(i === open ? -1 : i)} aria-expanded={i === open}>
                <span className="when">{t.when}</span>
                <span className="what">{t.title}</span>
              </button>
              {i === open && <p>{t.text}</p>}
            </Reveal>
          ))}
        </ol>
      </Band>
      <Footer />
    </>
  );
}

export default Digital;
