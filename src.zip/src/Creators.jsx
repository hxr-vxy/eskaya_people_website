import Footer from "./Footer.jsx";

import { TEAM } from "./assets/images/index.js";
import { Reveal, Band } from "./components.jsx";

const { lovelyn, harvey, jilliane, amber, jelyn, kervee, jarl, francis } = TEAM;

// Cee Jhay has no image in /assets yet: add e.g. ceejhay.png, import it, and set `img`.
const LEADER = { name: "Lovelyn Pojas", role: "Group Leader", img: lovelyn };
const DEV = { name: "Harvey Quibol III", role: "Developer", img: harvey };
const RESEARCHERS = [
  { name: "Jilliane Aguanza", img: jilliane }, { name: "Amber Perote", img: amber }, { name: "Jelyn Betco", img: jelyn },
  { name: "Kervee Cosinero", img: kervee }, { name: "Jarl Sabillano", img: jarl }, { name: "Francis Oldenaria", img: francis },
  { name: "Cee Jhay", img: null },
].map((r) => ({ ...r, role: "Researcher" }));

function Person({ p }) {
  const initials = p.name.split(" ").map((w) => w[0]).slice(0, 2).join("");
  return (
    <figure className="person" tabIndex={0}>
      <div className="avatar">
        {p.img ? <img src={p.img} alt={p.name} loading="lazy" /> : <span className="initials" aria-hidden="true">{initials}</span>}
        <figcaption><strong>{p.name}</strong><span>{p.role}</span></figcaption>
      </div>
      <div className="label"><strong>{p.name}</strong><span>{p.role}</span></div>
    </figure>
  );
}

function Creators() {
  return (
    <>
      <header className="pagehead">
        <div className="wrap team-head">
          <p className="kicker">Meet the Creators</p>
          <h1>The Team Behind This Website</h1>
          <div className="lead"><p>The people who researched, designed, and built this project.</p></div>
        </div>
      </header>

      <Band>
        <section aria-label="Org tree" className="org">
          <Reveal><h2>Org Tree</h2></Reveal>
          <div className="tree">
            <div className="node"><Person p={LEADER} /></div>
            <div className="stem" />
            <div className="node"><Person p={DEV} /></div>
            <div className="stem" />
            <div className="researchers">
              {RESEARCHERS.map((r) => (<div className="node" key={r.name}><Person p={r} /></div>))}
            </div>
          </div>
        </section>
      </Band>
      <Footer />
    </>
  );
}

export default Creators;
